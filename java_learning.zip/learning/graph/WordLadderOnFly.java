package graph;
/**
 * Given a list of words and two words (start and end), find the shortest transformation sequence from start to end, such that:
 * - Only one letter can be changed at a time
 * - The word after one letter change must be in the list of words
 * - The word after one letter change must be a valid word
 * - The word after one letter change must be a word that is one letter away from the previous word
 * - The word after one letter change must be a word that is one letter away from the next word
 * - The word after one letter change must be a word that is one letter away from the previous word
 * 
 * For example:
 *
 * wordList = ["hot","dot","dog","lot","log","cog","lead", "load", "goad", "gold", "dead", "head", "held", "bold", "told"]
 * 
 * start = "lead"
 * end = "gold"
 * Output: ["lead", "load", "goad", "gold"]
 * 
 * start = "lead"
 * end = "gold"
 * Output: ["lead", "load", "goad", "gold"]
 * 
 * Approach:
 * 1. Use BFS to find the shortest path from start to end
 * 2. Use a queue to store the words in the current path
 * 3. Generate all the words that are one letter away from the current word
 *    - for each word, check if it is in the word list
 *    - if it is, add it to the queue
 *    - if it is not, skip it
 * 4. If the word is the end word, return the path
 * 5. If the word is not the end word, continue the BFS
 * 6. If the queue is empty, return an empty list
 * 7. Return the shortest path
 * 
 */

import java.util.*;

public class WordLadderOnFly {
    public static void main(String[] args) {
        System.out.println("WordLadderOnFly !");
        List<String> wordList = Arrays.asList("hot","dot","dog","lot","log","cog","lead", "load", "goad", "gold", 
        "dead", "head", "held", "bold", "told", "ape", "apt", "opt", "oat","mat", "man");
        Set<String> wordSet = new HashSet<>(wordList);
        

        testWordLadder(wordSet, "lead", "gold");
        testWordLadder(wordSet, "goad", "held");
        testWordLadder(wordSet, "ape", "man");
    }

    private static void testWordLadder(Set<String> wordList, String start, String end) {
        System.out.println("========== testWordLadder from '" + start + "' to '" + end + "' ==========");
        List<String> wordPath = new ArrayList<>();
        int steps = findWordLadder(wordList, start, end, wordPath);
        System.out.println("Result: " + steps + " wordPath: " + wordPath);
        System.out.println("========== End of testWordLadder ==========\n");
    }

    private static int findWordLadder(Set<String> wordList, String start, String end, List<String> wordPath) {
        System.out.println("========== Finding word ladder from '" + start + "' to '" + end + "' ==========");
        if (start.equals(end)) {
            wordPath.clear();
            wordPath.add(start);
            return 0;
        }
        if (!wordList.contains(end)) {
            return -1;
        }

        Queue<String> queue = new LinkedList<>();
        queue.offer(start);

        Set<String> visited = new HashSet<>();
        visited.add(start);
        int stepCnt = 0;
        boolean found = false;
        Map<String, String> parentMap = new HashMap<>();

        while (!queue.isEmpty() && !found) {
            int size = queue.size();
            stepCnt++;

            // process level by level
            for (int i = 0; i < size; i++) {
                String currentWord = queue.poll();
                char[] currentWordChars = currentWord.toCharArray();

                // for each character in the current word, replace it with one of the 26 letters
                for (int j = 0; j< currentWordChars.length; j++) {
                    char originalChar = currentWordChars[j];
                    // try all the 26 letters
                    for (char c = 'a'; c <= 'z'; c++) {  // try all the letters in the alphabet for the current character position
                        // if same letter, skip
                        if (c == originalChar) continue;
                        // replace the character with the new letter and see if that word exists in the word list
                        currentWordChars[j] = c;
                        String newWord = new String(currentWordChars);
                        // if the new word is in the word list, add it to the queue
                        if (wordList.contains(newWord) && !visited.contains(newWord)) {
                            parentMap.put(newWord, currentWord);
                            queue.offer(newWord);
                            visited.add(newWord);
                            if (newWord.equals(end)) {
                                found = true;
                                break;
                            }
                        }
                    }                    
                     // restore to the original character
                    currentWordChars[j] = originalChar;
                    if (found) {
                        break;
                    }
                }  //                              
                if (found) {
                    break;
                }
            }            
        }
        if (!found) {
            stepCnt = -1;
        }

        wordPath.clear();
        String current = end;
        while (current != null) {
            wordPath.add(current);
            current = parentMap.get(current);
        }
        Collections.reverse(wordPath);

        return stepCnt;
    }
}