import java.util.TreeSet;
import java.util.Set;

public class Interval {
 
  private final Set<Integer> result = new TreeSet<>();
 
  public void addInterval(int from, int to) {
    for (int i = from; i < to; i++) {
      result.add(i);
    }
    System.out.println(result);
  }
 
  public int getTotalCoveredLength() {
    return result.size();
  }
 
  public static void main(String[] args) throws Exception {
    Interval i = new Interval();
    i.addInterval(3, 6);
    i.addInterval(8, 9);
    i.addInterval(1, 5);
/*     i.addInterval(1, 1); */
    System.out.println(i.getTotalCoveredLength());
  }
}


