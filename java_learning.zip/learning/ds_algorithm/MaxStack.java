package ds_algorithm;

import java.util.*;

/**
 * A stacklike data structure that also allows stacklike access
 * to its elements by their value.
 * For example, given a stack of {1, 3, 2, 5, 3, 4, 5, 2}
 * peek() -> 2, peekMax() -> 5
 * pop() -> 2; peek() -> 5, peekMax() -> 5
 * pop() -> 5; peek() -> 4, peekMax() -> 5
 * push(6); peek() -> 6, peekMax() -> 6
 * popMax() -> 6; peek -> 4, peekMax() -> 5
 * popMax() -> 5; peek -> 4, peekMax() -> 4

 */
public interface MaxStack<T extends Comparable<T>> {
    // The standard three Stack methods:
    /** Add an element to the stack. */
    public void push(T toPush);
    /** Return the top value on the stack. */
    public T peek();
    /** Remove and return the top value from the stack. */
    public T pop();
    // Two special methods, so this isn't just 'implement a stack':
    /** Return the largest value in the stack. (Remember that T must implement Comparable.) */
    public T peekMax();
    /** Remove and return the largest value from the stack. */
    public T popMax();
}

/**
 * Challenge: popMax() is not O(1), it must remove the max whereever it sits in the stack, not
 * juist at the top.  This breaks the two-stack approach.
 * 
 * Reasoning: What operations do we actually need and what data structure are good at each?
 * - push() and pop() are O(1) operations, so we can use a stack to store the elements
 * - find & remove max efficiently w/o O(n)
 * - remove an artibrary element by position (doubly linked list)
 * - Easily track where an element lives across multiple data structures (hashmap)
 * 
 * Solution: doubly linked list with treemap (sorted map)
 * - doubly linked list supports O(1) push (add to tail) and pop (remove from tail)
 * - doubly linked list supports O(1) removal of any arbitrary element by position
 * - treemap maps value to list of nodes (same values)
 * - treemap keeps key sorted, so max is always at the end O(log n)
 * - treemap support O(long n) for insertion, deletion and lookup
 * - heap supports O(1) for max peek, but not efficiently for remove artibrary element w/o O(n)
 * 
 * Approach:
 * 1. Use a stack to store the elements (normal stack operations)
 * 2. To support peekMax() and popMax(), we need a way to keep track of elements in the order of their values
 *    - with quick access to the maximum element, we can use a priority queue or a sorted list
 * 3. The challenge here is keeping both data structures in sync
 * 4. When pop() happens, remove from stack and the 
 * 
 */


class MaxStackImpl implements MaxStack<Integer> {
    private static class Node<Integer> {
        private Integer value;
        private Node<Integer> prev;
        private Node<Integer> next;
     
        public Node(Integer value) {
            this.value = value;
        }
    }

    private final TreeMap<Integer, List<Node<Integer>>> valueToNodes = new TreeMap<>();
    private Node<Integer> head = null;
    private Node<Integer> tail = null;

    /**
     * Logic:
     * - create a new node with value
     * - add to tail of the DDL: O(1)
     * - add to treemap with value as the key and node as the value: O(log n)
     * Runtime:
     */
    public void push(Integer value) {
        Node<Integer> newNode = new Node<>(value);
        addToTail(newNode);
        valueToNodes.computeIfAbsent(value, k -> new ArrayList<Node<Integer>>()).add(newNode);
    }

    /**
     * Logic:
     * - add to tail of the DDL: O(1)
     * - edge cases: when root is null
     * @param node
     */
    private void addToTail(Node<Integer> node) {
        if (head == null) {
            head = node;
            tail = node;            
        } else {
            tail.next = node;
            node.prev = tail;
            tail = node;
        }
        
    }

    /**
     * Logic:
     * - remove from the tail of the DDL: O(1)
     * - use the node.value to remove from the list of values in the treemap: O(log n)
     * - if the list of values is empty, remove the value from the treemap
     * - return the value of the node
     * Edge cases: when stack is empty (both head and tail are null)
     * @return
     */
    public Integer pop() {
        if (head == null) {
            return null;
        }

        Node<Integer> nodeToRemove = tail;
        removeFromTail();
        removeFromValueToNodes(nodeToRemove);
        return nodeToRemove.value;
    }

    /**
     * Logic:
     * - remove from the tail of the DDL: O(1)
     * - edge cases: when stack is empty (both head and tail are null)
     * @return
     */
    private void removeFromTail() {
        if (head == null) {
            return;
        }

        tail = tail.prev;
        if (tail == null) {
            head = null;
        } else {
            tail.next = null;
        }
    }

    private void removeFromValueToNodes(Node<Integer> nodeToRemove) {
        List<Node<Integer>> nodes = valueToNodes.get(nodeToRemove.value);
        if (nodes != null) {
            nodes.remove(nodeToRemove);
            if (nodes.isEmpty()) {
                valueToNodes.remove(nodeToRemove.value);
            }
        }
    }

    /**
     * Logic:
     * - return the value of the head of the DDL: O(1)
     * @return
     */
    public Integer peek() {
        if (tail == null) {
            return null;
        }
        return tail.value;
    }

    

    /**
     * Logic:
     * - return the key of the last entry in the treemap: O(log n)
     * @return
     */
    public Integer peekMax() {
        if (valueToNodes.isEmpty()) {
            return null;
        }
        return valueToNodes.lastKey();
    }

    /**
     * Logic:
     * - get the max value from the last entry in the treemap: O(log n)
     * - get the node from the list: O (log n)
     * - remove the node from the DDL: O(1)
     * - remove the value from the treemap
     * - return the value
     * @return
     */
    public Integer popMax() {
        if (valueToNodes.isEmpty()) {
            return null;
        } 
        Integer maxValue = valueToNodes.lastKey();
        List<Node<Integer>> nodes = valueToNodes.get(maxValue);
        
        Node<Integer> nodeToRemove = nodes.removeLast();
      
        removeFromDoublyLinkedList(nodeToRemove);
        return maxValue;

    }

    private void removeFromDoublyLinkedList(Node<Integer> nodeToRemove) {
        if (nodeToRemove == tail) {
            removeFromTail();
        } else if (nodeToRemove == head) {
            head = head.next;
            if (head == null) {
                tail = null;
            } else {
                head.prev = null;
            }
        } else {
            // node is in the middle of the list
            nodeToRemove.prev.next = nodeToRemove.next;
            nodeToRemove.next.prev = nodeToRemove.prev;
            nodeToRemove.prev = null;
            nodeToRemove.next = null;
        }
    }

    public boolean isEmpty() {
        return head == null;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Stack (bottom→top): [");
        Node<Integer> cur = head.next;
        while (cur != tail) {
            sb.append(cur.value);
            if (cur.next != tail) sb.append(", ");
            cur = cur.next;
        }
        sb.append("]");
        if (tail != null) {
            sb.append("  |  max=").append(peekMax());
        }
        return sb.toString();
    }

    private static void test1(){
        System.out.println("MaxStackImpl !");
        MaxStackImpl maxStack = new MaxStackImpl();
        System.out.println("=== Push 3, 1, 5, 2 ===");
        maxStack.push(3);
        maxStack.push(1);
        maxStack.push(5);
        maxStack.push(2);
        System.out.println(maxStack.toString());
        System.out.println("");

        System.out.println("peek: " + maxStack.peek()); // 2
        System.out.println("peekMax: " + maxStack.peekMax()); // 5
        System.out.println("pop: " + maxStack.pop()); // 2
        System.out.println("peek: " + maxStack.peek()); // 5
        System.out.println("peekMax: " + maxStack.peekMax()); // 5
        System.out.println("pop: " + maxStack.pop()); // 5
        System.out.println("peek: " + maxStack.peek()); // 1
        System.out.println("peekMax: " + maxStack.peekMax()); // 3
        System.out.println("pop: " + maxStack.pop()); // 1
        System.out.println("peek: " + maxStack.peek()); // 3
    }

    private static void test2(){
        MaxStackImpl ms = new MaxStackImpl();

        System.out.println("=== Push 3, 1, 5, 2 ===");
        ms.push(3);
        ms.push(1);
        ms.push(5);
        ms.push(2);
        System.out.println(ms);
        System.out.println("top()    = " + ms.peek());    // 2
        System.out.println("getMax() = " + ms.peekMax()); // 5

        System.out.println("\n=== popMax() ===");
        System.out.println("popMax() = " + ms.popMax()); // 5
        System.out.println(ms);                           // max reverts to 3

        System.out.println("\n=== pop() ===");
        System.out.println("pop()    = " + ms.pop());    // 2
        System.out.println(ms);

        System.out.println("\n=== Push duplicate max: push(3) ===");
        ms.push(3);
        System.out.println(ms);                           // two 3s; max=3
        System.out.println("popMax() = " + ms.popMax()); // removes most-recent 3
        System.out.println(ms);

        System.out.println("\n=== Pop remaining elements ===");
        System.out.println("pop() = " + ms.pop());       // 1
        System.out.println("pop() = " + ms.pop());       // 3
        System.out.println("isEmpty: " + ms.isEmpty());

        System.out.println("\n=== Exception on empty stack ===");
        try {
            ms.pop();
        } catch (NoSuchElementException e) {
            System.out.println("Caught: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        //test1();
        test2();
    }
}
