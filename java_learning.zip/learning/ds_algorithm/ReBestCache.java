package ds_algorithm;

import java.util.Set;
import java.util.Map;
import java.util.HashSet;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * This cache is a read through cache with a size limit. Each item has a key and value. The value
 * has a rank, which is used in the eviction policy, based on the lowest rank.
 * 
 * When the cache is full, the one with the lowest rank is removed.
 * When a item is not found in the cache, it is loaded from the database.
 */
public class ReBestCache<K, V extends Rankable> {
    private final int size;
    private final DataSource<K, V> dataSource;
    // this is the key to this problem, using a tree map to store the rank in order, which is used during eviction
    // this makes it O(log n) to find the lowest rank
    // this tree map is sorted by rank, which is the key
    // the value is a set of keys, which are the keys of the items in the cache
    private final TreeMap<Long, Set<K>> rankMap;
    private final Map<K, V> keyToValue;
    // Single lock to keep keyToValue and rankMap consistent.
    // We still use ConcurrentHashMap so cache hits do not require locking.
    private final Object lock = new Object();

    public ReBestCache(int size, DataSource<K, V> dataSource) {
        this.size = size;
        this.dataSource = dataSource;
        // this is the key to this problem, using a tree map to store the rank in order, which is used during eviction
        // this makes it O(log n) to find the lowest rank
        // this tree map is sorted by rank, which is the key
        // the value is a set of keys, which are the keys of the items in the cache
        this.rankMap = new TreeMap<Long, Set<K>>();
        this.keyToValue = new ConcurrentHashMap<K, V>();
    }

    public V get(K key) {
        V value = keyToValue.get(key);

        if (value != null) {
            return value;
        }

        // Miss path: must synchronize updates to rankMap and eviction.
        synchronized (lock) {
            // Double-check in case another thread populated it while we waited.
            value = keyToValue.get(key);
            if (value != null) {
                return value;
            }

            // Get value from data source.
            value = dataSource.get(key);
            if (value == null) {
                return null;
            }
            keyToValue.put(key, value);
            addToRankMap(key, value);
            evictIfNeeded();
            return value;
        }
    }

    private void evictIfNeeded() {
        // compare cache size to size limit
        if (keyToValue.size() > size) {
           // eviction policy is based on the lowest rank
           Map.Entry<Long, Set<K>> lowestRankEntry = rankMap.firstEntry();
           if (lowestRankEntry == null) {
               return;
           }
           Long lowestRank = lowestRankEntry.getKey();
           // these are the keys with the lowest rank
           Set<K> lowestRankKeySet = lowestRankEntry.getValue();
           if (lowestRankKeySet == null || lowestRankKeySet.isEmpty()) {
               rankMap.remove(lowestRank);
               return;
           }
           // pick one key from the list
           K lowestRankKey = lowestRankKeySet.iterator().next();
           // remove the key from the set
           lowestRankKeySet.remove(lowestRankKey);
           if (lowestRankKeySet.isEmpty()) {
            // remove the entry from the rank map if no more keys in the set
            rankMap.remove(lowestRank);
           }
           // remove the key from the cache
           keyToValue.remove(lowestRankKey);
        }
    }

        
    private void addToRankMap(K key, V value) {
        long rank = value.getRank();
        Set<K> keys = rankMap.get(rank);
        if (keys == null) {
            keys = new HashSet<K>();
            rankMap.put(rank, keys);
        }
        keys.add(key);
    }

}
