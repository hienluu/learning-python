package ds_algorithm;

public interface Rankable {
    long getRank();
}
