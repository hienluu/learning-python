package ds_algorithm;

import java.util.*;

/**
 * A basic implementation of the MaxStack interface.
 * - push, pop, peek and peekMax are all O(1) operations.
 * 
 * Approach:
 * 1. Use a stack to store the elements
 * 2. Use a max stack to store the maximum elements corresponding to the elements in the stack
 * 
 */
public class MaxStackBasic {
    private Stack<Integer> stack;
    private Stack<Integer> maxStack;
    private int maxValueSoFar;

    public MaxStackBasic() {
        this.stack = new Stack<>();
        this.maxStack = new Stack<>();
    }
    
    public void push(int value) {
        stack.push(value);
        maxValueSoFar = Math.max(maxValueSoFar, value);
        
        // keep pushing the same max value so far
        maxStack.push(maxValueSoFar);
        
    }

    public int pop() {
        if (stack.isEmpty()) {
            return -1;
        }
        int value = stack.pop();
        maxStack.pop();
        return value;
    }

    public int peek() {
        if (stack.isEmpty()) {
            return -1;
        }
        return stack.peek();
    }

    public int peekMax() {
        if (maxStack.isEmpty()) {
            return -1;
        }
        return maxStack.peek();
    }

    public static void main(String[] args) {
        System.out.println("MaxStackBasic !");
        MaxStackBasic maxStack = new MaxStackBasic();
        maxStack.push(3);
        maxStack.push(1);
        maxStack.push(5);
        maxStack.push(2);

        System.out.println("peekMax: " + maxStack.peekMax());
        System.out.println("pop: " + maxStack.pop());
        System.out.println("peekMax: " + maxStack.peekMax());

        System.out.println("pop: " + maxStack.pop());
        System.out.println("peekMax: " + maxStack.peekMax());

        System.out.println("pop: " + maxStack.pop());
        System.out.println("peekMax: " + maxStack.peekMax());

        System.out.println("pop: " + maxStack.pop());
        System.out.println("peekMax: " + maxStack.peekMax());

    }
}
