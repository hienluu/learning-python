package recursion;
/**
 * This is an exmaple of a topological sort problem.
 * We are given a list of courses and a list of prerequisites.
 * We need to find a valid order of courses that satisfies the prerequisites.
 * 
 * Example:
 *  Course 0 → must be taken before Course 1
 *  Course 0 → must be taken before Course 2
 *  Course 1 → must be taken before Course 3
 *  Course 2 → must be taken before Course 3
 *  
 *  Translates to:
 *  Course 0 is prerequisite for Course 1
 *  Course 0 is prerequisite for Course 2
 *  Course 1 is prerequisite for Course 3
 *  Course 2 is prerequisite for Course 3
 *  
 *  Input:
 *  numCourses = 4
 * 
 *  A readable sentence template is:
 *   -  "{a, b}" means: to take course a, you must first take course b
 *   - the prequisite is the second element in the pair
 *   - in other words, course a requires comes course b first
 * 
 *  From the graph perspective, we have a directed graph
 *   b -> a means course b is prerequisite (comes before) course a
 * 
 *  Input:
 *  numCourses = 4
 *  prerequisites = {{1, 0}, {2, 0}, {3, 1}, {3, 2}};
 *  Output: [0, 1, 2, 3]
 * 
 *  Approach:
 *  1. We can use a topological sort algorithm to find a valid order of courses that satisfies the prerequisites.
 * 
 * 
 *  Approach:
 *  - We can use a topological sort algorithm to find a valid order of courses that satisfies the prerequisites.
 *  - First build the dependency graph in the form of adjacency list
 *  - The adjacency list is a list of courses that are prerequisites for each course
 *  - The key is the prerequisite course, the value is the list of courses can be taken after the prerequisite course
 *  - For example, if course 0 is prerequisite for course 1 and course 2, then the adjacency list would be:
 *    0 → [1, 2]
 *    1 → [3]
 *    2 → [3]
 *    3 → []
 *  - Then use DFS-based topological sort algorithm to find a valid order of courses that satisfies the prerequisites
 * 
 * 
 *  Complexity:
 *  - time complexity: O(V + E) where V is the number of courses and E is the number of prerequisites
 *  - space complexity: O(V + E) where V is the number of courses and E is the number of prerequisites
 */

import java.util.*;

public class CourseOrder {
    public static void main(String[] args) {
        System.out.println("CourseOrder !");
        CourseOrder courseOrder = new CourseOrder();
        int[][] prerequisites = {{1, 0}, {2, 0}, {3, 1}, {3, 2}};
        int numCourses = 4;
        List<Integer> result = courseOrder.findOrder(numCourses, prerequisites);
        System.out.println("Result: " + result);
    }

    private  Map<Integer, List<Integer>> adjacencyGraph;
   

    private Map<Integer, List<Integer>> buildGraph(int numCourses, int[][] prerequisites) {
        adjacencyGraph = new HashMap<>(numCourses);
        for (int course = 0; course < numCourses; course++) {
            adjacencyGraph.put(course, new ArrayList<>());
        }
        for (int[] prereq : prerequisites) {
            int course = prereq[0];
            int prerequisite = prereq[1];
            adjacencyGraph.computeIfAbsent(prerequisite, k -> new ArrayList<>()).add(course);
        }
        return adjacencyGraph;
    }

    public List<Integer> findOrder(int numCourses, int[][] prerequisites) {
        buildGraph(numCourses, prerequisites);
        printGraph(adjacencyGraph);
       
        Set<Integer> visited = new HashSet<>();
        Set<Integer> visiting = new HashSet<>();
        List<Integer> result = new ArrayList<>();
       
        for (int course = 0; course < numCourses; course++) {
            if (!dfs(course, visited, visiting, result)) {
                return new ArrayList<>(); // if the course is cyclic, return an empty list
            }
        }

        // before reversing
        System.out.println("*** Result before reversing: " + result);
        Collections.reverse(result);
        return result;
    }

    /**
     * This is a helper method to perform a depth first search on the graph to find a valid order of courses that satisfies the prerequisites.
     * @param course
     * @param visited
     * @param visiting
     * @param result
     * @return true if the course is visited, false if the course is cyclic
     */
    private boolean dfs(int course, Set<Integer> visited, Set<Integer> visiting, List<Integer> result) {
        //base case - if the course is already visited, return true
        if (visited.contains(course)) {
            return true; // success, the course is already visited
        }
        //base case - if the course is in the visiting set, meaning cycle detected return false
        if (visiting.contains(course)) {
            return false;
        }
        //recursive case - visit the course
        visiting.add(course);
        // visit all the prerequisites of the course in DFS manner
        for (int prerequisite : adjacencyGraph.get(course)) {
            if (!dfs(prerequisite, visited, visiting, result)) {
                return false;
            }
        }
        // backtracking, it is no longer on the recursion path
        visiting.remove(course);
        // we have confirmed all required downstream work from this course is complete.
        visited.add(course);
        // add the course to the result list
        // this is the order of courses that satisfies the prerequisites
        result.add(course);
        return true; // success, the course is added to the result list


        /* 
         * A mental model that helps using browser tabs metaphor:
         * visiting = "currently open tabs"
         * visited = "tabs already fully read"
         * result = "append to done list when closing tab"
         */
    }


    private void printGraph(Map<Integer, List<Integer>> adjGraph) {
        for (Map.Entry<Integer, List<Integer>> entry : adjGraph.entrySet()) {
            System.out.println(entry.getKey() + " -> " + entry.getValue());
        }
    }

}
