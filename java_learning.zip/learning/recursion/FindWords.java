package recursion;

import java.util.Set;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.HashSet;
import java.util.Collections;
/**
 * Given a list of words, find all the words in the list that can be formed with any subset
 * of the given list of characters.  Each character can only be used once.
 * 
 * Example:
 * word list = {"pot", "top", "hole", "pothole", "stopword", "stop", "word", "cold"}
 * characters = "ehloopts"
 * 
 * Output: {"pot", "top", "hole", "pothole", }
 * 
 * Approach:
 * 1. Create a trie of the words (dictionary to speed the lookup by prefix)
 *    Each node in the trie represents a character and has a list of children nodes.
 *    The last node in the trie represents the end of a word, need a flag to indicate this.
 *    The trie is used to store the words in the word list.
 * 2. For each character in the characters string, check if it can form a word in the trie
 *    - each character in the original list of characters can be used only once
 *    - each character in the original list of characters can be used as a starting prefix to form a word in the trie 
 *    - use recursion to form the word by traversing the trie, starting from the first character in the original list of characters
 * 3. If it can, add the word to the result list
 * 4. Return the result list
 * 
 * Complexity:
 *  - time complexity: O(n!) where n is the number of characters in the characters string
 *  - space complexity: O(n^2) where n is the recursion depth, each recursive call creates a new list of characters of roughly n/2 size
 */
public class FindWords {
    public static void main(String[] args) {
        String[] wordList = {"pot", "top", "hole", "pothole", "pots", "spot", "hot"};
        String characters = "ehloopts";
        
        
        FindWords findWords = new FindWords();
        findWords.initialize(new HashSet<>(Arrays.asList(wordList)));
        List<String> result = findWords.findWords(characters);
        System.out.println("========== Result: ==========");
        for (String word : result) {
            System.out.println(word);
        }

        result = findWords.findWords("opst");
        System.out.println("========== Result: ==========");
        for (String word : result) {
            System.out.println(word);
        }

        result = findWords.findWords("pst");
        System.out.println("========== Result: ==========");
        for (String word : result) {
            System.out.println(word);
        }
    }

    /* tried data structure to store the words in the word list */
    private class TrieNode {
        private Map<Character, TrieNode> children = new HashMap<>();
        private boolean isEndOfWord = false;

        public void addWord(String word) {
            addWordHelper(word, 0, this);
        }

        /**
         * This helper contains the logic to add a word to the trie recursively.
         * It first uses the character the the given index and checks the children map of the current node.
         * If the character is not in the children map, a new node is created for it.
         * The recursive case is then used to add the rest of the word to the trie.
         * When the index is equal to the length of the word, the end of word flag is set to true.
         * 
         * @param word
         * @param idx
         * @param node
         */
        private void addWordHelper(String word, int idx, TrieNode node) {
            // base case - if the index is equal to the length of the word, set the end of word flag to true
            if (idx == word.length()) {
                node.isEndOfWord = true;
                return;
            }

            // get the current char
            Character currentChar = word.charAt(idx);
            // if current character is not in the children map, create a new node for it
            if (!node.children.containsKey(currentChar)) {
                node.children.put(currentChar, new TrieNode());
            }

            // recursive case - add the rest of the word to the trie
            addWordHelper(word, idx + 1, node.children.get(currentChar));
        }

        public void printTrie() {
            System.out.println("[root]");
            printTrieDfs(rootNode, "", true, '\0');
        }
        
        private void printTrieDfs(TrieNode node, String prefix, boolean isLast, char edgeChar) {
            if (edgeChar != '\0') {
                String endMarker = node.isEndOfWord ? " (word)" : "";
                System.out.println(prefix + (isLast ? "`-- " : "|-- ") + edgeChar + endMarker);
            }
        
            List<Character> keys = new ArrayList<>(node.children.keySet());
            Collections.sort(keys); // deterministic order
        
            for (int i = 0; i < keys.size(); i++) {
                char ch = keys.get(i);
                TrieNode child = node.children.get(ch);
                boolean childIsLast = (i == keys.size() - 1);
        
                String nextPrefix = edgeChar == '\0'
                    ? "" // root had no printed branch symbol
                    : prefix + (isLast ? "    " : "|   ");
        
                printTrieDfs(child, nextPrefix, childIsLast, ch);
            }
        }
    }

    private TrieNode rootNode = new TrieNode();

    public void initialize(Set<String> wordList) {       
        for (String word : wordList) {
            rootNode.addWord(word);
        }
        System.out.println("========== Trie: ==========");
        rootNode.printTrie();
    }

    public List<String> findWords(String characters) {
        System.out.println("========== Finding words for characters: " + characters + " ==========");
        List<String> result = new ArrayList<>();
        List<Character> charList = characters.chars().mapToObj(c -> (char) c).collect(Collectors.toList());
        findWordsHelper(charList,  rootNode, "", result);

        return result;
    }

    /**
     * Helper method to find the words in the trie using recursion.
     * The charList is the list of characters that are available to form a word, it should be one less than the original list of characters.
     * The node is the current node in the trie, it is the starting point for the search.
     * The currentWord is the word that is being formed, it is initially empty.
     * The result is the list of words that are found in the trie.
     * @param charList
     * @param node
     * @param currentWord
     * @param result
     */
    private void findWordsHelper(List<Character> charList,  
                                 TrieNode node, String currentWord, List<String> result) {
        
        // base case - when no more character left in charList 
        if (charList.size() == 0) {
            System.out.println("**** charList is empty: Adding word: " + currentWord);
            result.add(currentWord.toString());
            return;
        }

        // there would be sub words that can be formed with the remaining characters
        if (node.isEndOfWord) {
            result.add(currentWord.toString());
        }

        // recursive case - for each character in the char list, check if it can form a word in the trie
        for (Character c : charList) {
            // is this c in the children map of the current node?
            if (node.children.containsKey(c)) {
              
                // remove the character from the char list, create a new list to avoid modifying the original list
                // new list has one less character than the original list
                List<Character> newCharList = new ArrayList<>(charList);
                newCharList.remove(c);

                // recursive call to find the next word
                findWordsHelper(newCharList, node.children.get(c), currentWord + c, result);
            }
        }
    }
}