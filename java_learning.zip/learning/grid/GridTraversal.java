package grid;

import java.util.Map;
import java.util.HashMap;

public class GridTraversal {
    public static void main(String[] args) {
        System.out.println("GridTraversal !");
        int[][] grid1 = {
            {1, 1, 1},
            {1, 0, 0},
            {1, 0, 1},
        };
        System.out.println("largest island for grid1 is " + largestIsland(grid1).toString());

        int[][] grid2 = {
            {1, 1, 0, 0, 0},
            {1, 1, 0, 0, 0},
            {0, 0, 0, 1, 1},
            {1, 1, 0, 1, 1},
            {0, 0, 0, 1, 1},
        };
        System.out.println("largest island for grid2 is " + largestIsland(grid2).toString());
    }

    /**
     * This is the driver method to find the largest island in the grid.
     * It iterates through the grid and calls the helper method to find the largest island from each cell that is a 1.
     * It returns a map of the largest island and its size.
     * The key is the starting cell of the island, the value is the size of the island.
     * 
     * @param grid
     * @return
     */
    public static Map<String, Integer> largestIsland(int[][] grid) {
        int maxIsland = 0;
        Map<String, Integer> result = new HashMap<>();
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[i].length; j++) {
                if (grid[i][j] == 1) {
                    int islandSize = largestIslandHelper(grid, i, j);
                    if (islandSize > maxIsland){
                        result.clear();
                        maxIsland = islandSize;
                        result.put(i + "," + j, islandSize);                        
                    }
                }
            }
        }
        return result;
    }

    /**
     * Helper method to find the largest island from a given cell.
     * @param grid
     * @param i
     * @param j
     * @return
     */
    public static int largestIslandHelper(int[][] grid, int i, int j) {
        // base case - check out of bounds for both rows and columns
        if (i < 0 || i >= grid.length || j < 0 || j >= grid[i].length) {
            return 0;
        }

        // check if the current cell is a 0 to stop the traversal after boundary check
        if (grid[i][j] == 0) {
            return 0;
        }

        // mark the current cell as visited by setting it to 0
        grid[i][j] = 0;

        // traverse the 4 directions - horizontal (left, right) and vertical (up, down)
        int count = 1; // we are here because the current cell is a 1, therefore we increment the count by 1
        count += largestIslandHelper(grid, i + 1, j);
        count += largestIslandHelper(grid, i - 1, j);
        count += largestIslandHelper(grid, i, j + 1);
        count += largestIslandHelper(grid, i, j - 1);
        return count;
    }

}
