package grid;

import java.util.*;

public class SimpleBFS {
    // Direction vectors: Right, Left, Down, Up
    private static final int[][] DIRECTIONS = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};

    public static void main(String[] args) {
        System.out.println("SimpleBFS !");
        // 0 represents a free cell, 1 represents a blocked cell
        int[][] grid = {
            {0, 1, 0, 0 },
            {0, 0, 0, 0 },
            {1, 1, 0, 0 },
        };
        System.out.println("Shortest path in grid is " + shortestPath(grid));
    }

    public static int shortestPath(int[][] grid) {
        int rows = grid.length;
        int cols = grid[0].length;
        
        
        Queue<int[]> queue = new LinkedList<>();
        queue.offer(new int[] {0,0,1}); // row, col, steps

        while (!queue.isEmpty()) {
            int[] current = queue.poll();
            int row = current[0];
            int col = current[1];
            int nDist = current[2];

            // check if the current cell is the destination cell (bottom right corner)
            if (row == rows - 1 && col == cols - 1) {
                return nDist;
            }

            // explore the 4 directions
            for (int[] dir : DIRECTIONS) {
                int nRow = row + dir[0];
                int nCol = col + dir[1];
                
                // before adding to the queue, check if the cell coordinates are valid
                if (nRow >= 0 && nRow < rows && nCol >= 0 && nCol < cols && grid[nRow][nCol] == 0) {
                    queue.offer(new int[] {nRow, nCol, nDist +1});
                    // mark the cell as visited by setting it to 0
                    grid[nRow][nCol] = 1;
                }
            }
        }
        return -1; // if no path is found, return -1
        
    }
}
